using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainCharController : MonoBehaviour
{

    GameObject enemy;
    Animator anim;

    float movePower = 3f;
    
    void Start()
    {
        enemy = GameObject.FindGameObjectWithTag("Enemy");
        //find enemy
        anim = GetComponent<Animator>();
    }

    
    void Update()
    {

        if (enemy != null)
        {
            float dis = Mathf.Abs(transform.position.x - enemy.transform.position.x);

            if (dis < 3.0f)
            {
                anim.SetBool("isStand", false);
                anim.SetBool("isRun", false);
                anim.SetBool("isAttack", true);

                transform.position += Vector3.zero;
                // stop object

            }
            else
            {
                anim.SetBool("isStand", false);
                anim.SetBool("isRun", true);
                anim.SetBool("isAttack", false);

                transform.position += Vector3.right * movePower * Time.deltaTime;
                // move object
            }
        }
        else
        {
            anim.SetBool("isStand", true);
            anim.SetBool("isRun", false);
            anim.SetBool("isAttack", false);

            transform.position += Vector3.zero;
        } // if enemy die stop animation
    }

    

    private void FixedUpdate()
    {
        
    }
}
