using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackManager : MonoBehaviour
{

    [SerializeField]
    public GameObject attackSize1;
    public GameObject attackSize2;
    public GameObject attackSize3;

    float showTime = 3f;
    float currTime = 0;


    void Start()
    {

        attackSize1.gameObject.SetActive(false);
        attackSize2.gameObject.SetActive(false);
        attackSize3.gameObject.SetActive(false);


    }

    
    void Update()
    {


        if(currTime >= showTime)
        {
            int randomAttack = Random.Range(1, 4); // random range 1~3
            switch (randomAttack)
            {
                case 1:
                    attackSize1.gameObject.SetActive(true);break;
                case 2:
                    attackSize2.gameObject.SetActive(true);break;
                case 3:
                    attackSize3.gameObject.SetActive(true);break;
            }

            currTime = 0;
        }
        else
        {

            if(currTime >= 2f)
            {
                attackSize1.gameObject.SetActive(false);
                attackSize2.gameObject.SetActive(false);
                attackSize3.gameObject.SetActive(false);

            }
            currTime += Time.deltaTime;
        }


    }
}
