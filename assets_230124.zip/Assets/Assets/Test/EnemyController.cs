using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyController : MonoBehaviour
{

    Renderer rend;
    public Image hp;

    float nowHp = 100f;
    float fullHp = 100f;

    int itemValue;
    public GameObject item1;
    public GameObject item2;
    public Transform tran;

    GameObject item; // 충돌 후 destroy되어 exit이 일어나지 않는 경우 보완

    void Start()
    {
        rend = GetComponent<Renderer>();
    }

    
    void Update()
    {
        if(nowHp <= 0)
        {
            Destroy(gameObject);
        }

       

    }

    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        rend.material.color = Color.red;
        nowHp -= 5f; // test
        hp.fillAmount = (float)nowHp / (float)fullHp;

        item = collision.GetComponent<GameObject>();
        Destroy(item);

        // drop item
        itemValue = Random.Range(1, 4); // Range 1 ~ 3
        if(nowHp > 0f)
        {
            for(int i=0; i<itemValue; i++)
            {
                int ran = Random.Range(1, 3);
                float randomX = Random.Range(-3f,3f);

                switch (ran)
                {
                    case 1:
                        Instantiate(item1, new Vector3(tran.position.x + randomX, tran.position.y,0f), Quaternion.identity);break;
                    case 2:
                        Instantiate(item2, new Vector3(tran.position.x + randomX, tran.position.y, 0f), Quaternion.identity);break;
                }
                
            }
        }else if(nowHp <= 0f)
        {

            for(int i=0; i<10; i++)
            {
                int ran = Random.Range(1, 3);
                float randomX = Random.Range(-3f, 3f);

                switch (ran)
                {
                    case 1:
                        Instantiate(item1, new Vector3(tran.position.x + randomX, tran.position.y, 0f), Quaternion.identity); break;
                    case 2:
                        Instantiate(item2, new Vector3(tran.position.x + randomX, tran.position.y, 0f), Quaternion.identity); break;
                }
            }
        }
        
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        rend.material.color = Color.white;
    }


    private void OnTriggerExit2D(Collider2D collision)
    {
        rend.material.color = Color.white;
       
    }
}
