using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 
 
 캐릭터 원거리 공격 스크립트 입니다.

 */
public class MainChar_Skill2 : MonoBehaviour
{
    public Transform mainChar; // 메인 캐릭터 위치
    public GameObject item; // 원거리 공격시 발사체


    GameObject value;

    public void Throw()
    {

        value = Instantiate(item, mainChar.position, mainChar.rotation);

    }

    private void FixedUpdate()
    {
        if (value != null)
            value.GetComponent<Rigidbody2D>().velocity = new Vector3(10f, 0, 0);
    }


}
