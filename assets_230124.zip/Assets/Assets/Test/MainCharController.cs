using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/*
 해당 스크립트는 자동 전투시 작성된 스크립트 입니다.

진행 방식 : 게임 시작 시, 캐릭터 자동 적군으로 이동 후, 공격
 */
public class MainCharController : MonoBehaviour
{

    GameObject enemy;
    Animator anim;

    float movePower = 3f;
    
    void Start()
    {
        enemy = GameObject.FindGameObjectWithTag("Enemy");
        //find enemy
        anim = GetComponent<Animator>();
    }

    
    void Update()
    {

        if (enemy != null)
        {
            float dis = Mathf.Abs(transform.position.x - enemy.transform.position.x);

            if (dis < 3.0f)
            {
                anim.SetBool("isStand", false);
                anim.SetBool("isRun", false);
                anim.SetBool("isAttack", true);

                transform.position += Vector3.zero;
                // stop object

            }
            else
            {
                anim.SetBool("isStand", false);
                anim.SetBool("isRun", true);
                anim.SetBool("isAttack", false);

                transform.position += Vector3.right * movePower * Time.deltaTime;
                // move object
            }
        }
        else
        {
            anim.SetBool("isStand", true);
            anim.SetBool("isRun", false);
            anim.SetBool("isAttack", false);

            transform.position += Vector3.zero;
        } // if enemy die stop animation
    }

    

    private void FixedUpdate()
    {
        
    }
}
