using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpControl : MonoBehaviour
{

    public Rigidbody2D rigid; // 캐릭터의 rigidbody

    public GameObject ground;


    int mainLayer, groundLayer;

    void Start()
    {
        mainLayer = LayerMask.NameToLayer("Main");
        groundLayer = LayerMask.NameToLayer("UpGround");
    }


    public void Up()
    {

        ground.GetComponent<BoxCollider2D>().enabled = true;
        if (rigid.velocity.y == 0)
            rigid.velocity = new Vector3(0, 7f, 0);
      
        

    }

    public void Down()
    {
        ground.GetComponent<BoxCollider2D>().enabled = false;
    }


    void Update()
    {


        if (rigid.velocity.y > 0)
            Physics2D.IgnoreLayerCollision(mainLayer, groundLayer, true);
        else 
            Physics2D.IgnoreLayerCollision(mainLayer, groundLayer, false);
     

    }
}
