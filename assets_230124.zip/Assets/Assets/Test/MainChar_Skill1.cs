using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/*
 캐릭터 근거리 공격 스크립트 입니다.

공격 방법 : 몸통 박치기
 */

public class MainChar_Skill1 : MonoBehaviour
{

    public GameObject mainChar;
    public Transform trans; // 현재 위치 저장

    GameObject enemy;
    Animator anim;

    float dis; // 적과의 거리 저장
    float stayTime = 0; // 근접 거리 공격모션 적용 시간

    void Start()
    {
        enemy = GameObject.FindGameObjectWithTag("Enemy");
        //find enemy
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        dis = Mathf.Abs(transform.position.x - enemy.transform.position.x);
    }

    public void AttackEnemy()
    {

        while (stayTime < 3f)
        {
            anim.SetBool("isStand", false);
            anim.SetBool("isRun", true);
            anim.SetBool("isAttack", false);
            transform.position += Vector3.right * 4f;

            stayTime += Time.deltaTime;
        }

        
        
    }

    public void Back()
    {
        
    }
}
