using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonControl : MonoBehaviour
{

    public Image img_skill; // 쿨타임 표시시 이미지
    public Text txt_skill; // 쿨타임 표시시 남은 시간


    public float coolTime;
    private float currTime; // 스킬 사용 후 지난 시간
    private bool readyForSkill = true;


    public Transform mainChar; // 메인 캐릭터 위치
    public GameObject item; // 원거리 공격시 발사체


    GameObject value;

    //스킬 연출 함수는 따로 작성
    public void Throw()
    {

        value = Instantiate(item, mainChar.position, mainChar.rotation);
        Destroy(value, 1f);

    }

    private void FixedUpdate()
    {
        if (value != null)
            value.GetComponent<Rigidbody2D>().velocity = new Vector3(10f, 0, 0);
    }

    void Start()
    {

    }

    void Update()
    {
        if (readyForSkill)
            return;
        Check_CoolTime();
    }

    
    void Check_CoolTime()
    {
        currTime += Time.deltaTime;
        if(currTime < coolTime)
        {
            Set_FillAmount(currTime);
        }else if (!readyForSkill)
        {
            End_CoolTime();
        }
    }

    void End_CoolTime()
    {
        Set_FillAmount(coolTime);
        readyForSkill = true;
        txt_skill.gameObject.SetActive(false);
    }

    void Trigger_Skill()
    {
        if (!readyForSkill) return;

        Reset_CoolTime();
    }

    void Reset_CoolTime()
    {
        Throw(); // 스킬 함수는 여기에
        txt_skill.gameObject.SetActive(true);
        currTime = 0;
        Set_FillAmount(0);
        readyForSkill = false;
    }

    void Set_FillAmount(float value)
    {
        img_skill.fillAmount = value / coolTime;
        txt_skill.text = string.Format("{0}", value.ToString("0.0"));
    }

    public void btnDown()
    {
        Trigger_Skill();
    }

}

